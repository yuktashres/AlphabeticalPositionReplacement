
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author yuktashrestha
 */
public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        String characters = scan.nextLine().toLowerCase();
        int position = 0;

        for (int i = 0; i < characters.length(); i++) {

            if (characters.charAt(i) >= 'a' && characters.charAt(i) <= 'z') {
                position = characters.charAt(i) - 'a' + 1;
                System.out.println(position);
            } else {
                position = 0;
            }

        }

    }
}
